import com.azure.ai.textanalytics.TextAnalyticsClientBuilder;
import com.azure.ai.textanalytics.models.DetectLanguageInput;
import com.azure.ai.textanalytics.models.DetectLanguageResult;
import com.azure.ai.textanalytics.models.DetectedLanguage;
import com.azure.ai.textanalytics.models.TranslateOptions;
import com.azure.ai.textanalytics.models.TranslateResult;
import com.azure.ai.textanalytics.TextAnalyticsClient;
import com.azure.core.credential.AzureKeyCredential;

import java.util.List;

public class RealTimeTranslator {

    public static void main(String[] args) {
        // Replace YOUR_SUBSCRIPTION_KEY and YOUR_ENDPOINT with your actual Azure subscription key and endpoint
        String subscriptionKey = "YOUR_SUBSCRIPTION_KEY";
        String endpoint = "YOUR_ENDPOINT";

        // Create an instance of the TextAnalyticsClient
        TextAnalyticsClient textAnalyticsClient = new TextAnalyticsClientBuilder()
                .credential(new AzureKeyCredential(subscriptionKey))
                .endpoint(endpoint)
                .buildClient();

        // Sample user messages in different languages
        String userMessage1 = "Hello, how are you?";
        String userMessage2 = "¿Cómo estás?";
        String userMessage3 = "Comment ça va?";

        // Detect language for each user message
        detectAndTranslate(textAnalyticsClient, userMessage1);
        detectAndTranslate(textAnalyticsClient, userMessage2);
        detectAndTranslate(textAnalyticsClient, userMessage3);
    }

    private static void detectAndTranslate(TextAnalyticsClient textAnalyticsClient, String userMessage) {
        // Detect language of the user message
        DetectLanguageInput detectLanguageInput = new DetectLanguageInput(userMessage);
        DetectLanguageResult detectLanguageResult = textAnalyticsClient.detectLanguage(List.of(detectLanguageInput)).get(0);
        DetectedLanguage detectedLanguage = detectLanguageResult.getPrimaryLanguage();

        // Translate the user message to a target language (e.g., English)
        String targetLanguage = "en"; // English
        TranslateOptions translateOptions = new TranslateOptions(userMessage)
                .setTo(targetLanguage)
                .setSourceLanguage(detectedLanguage.getIso6391Name());

        TranslateResult translateResult = textAnalyticsClient.translate(List.of(translateOptions)).get(0);

        // Display the translated message
        System.out.println("User Message: " + userMessage);
        System.out.println("Detected Language: " + detectedLanguage.getName());
        System.out.println("Translated Message (" + targetLanguage + "): " + translateResult.getTranslatedText());
        System.out.println();
    }
}
