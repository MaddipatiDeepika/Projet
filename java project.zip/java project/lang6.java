import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class OfflineTranslationExample {

    public static void main(String[] args) {
        // Replace with the path to the Marian NMT translation model
        String modelPath = "/path/to/your/model/model.npz";

        // Example text to translate
        String textToTranslate = "Translate this text offline.";

        try {
            // Perform offline translation
            String translatedText = translateOffline(textToTranslate, modelPath);

            // Display the translation result
            System.out.println("Original Text: " + textToTranslate);
            System.out.println("Translated Text: " + translatedText);

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static String translateOffline(String textToTranslate, String modelPath) throws IOException, InterruptedException {
        // Command to perform translation using Marian NMT
        String command = String.format("marian-decoder -c %s -b 6", modelPath);

        // Run the translation command in the terminal
        Process process = Runtime.getRuntime().exec(command);
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
             BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {

            // Feed the input text to the translation process
            process.getOutputStream().write((textToTranslate + "\n").getBytes());
            process.getOutputStream().flush();
            process.getOutputStream().close();

            // Read the translated text from the process output
            StringBuilder translatedText = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                translatedText.append(line);
            }

            // Wait for the process to finish
            int exitCode = process.waitFor();

            // Check for errors
            StringBuilder errorMessage = new StringBuilder();
            while ((line = errorReader.readLine()) != null) {
                errorMessage.append(line);
            }

            if (exitCode != 0) {
                throw new IOException("Error during translation: " + errorMessage.toString());
            }

            return translatedText.toString();
        }
    }
}
