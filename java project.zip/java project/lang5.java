import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.translate.AutoMlTranslationClient;
import com.google.cloud.translate.v3.AutoMlTranslationSettings;
import com.google.cloud.translate.v3.TranslateTextRequest;
import com.google.cloud.translate.v3.TranslateTextResponse;
import com.google.protobuf.Value;

import java.io.FileInputStream;
import java.io.IOException;

public class CustomTranslationExample {

    public static void main(String[] args) {
        // Replace these with your actual Google Cloud project ID, model ID, and credentials file path
        String projectId = "YOUR_PROJECT_ID";
        String modelId = "YOUR_MODEL_ID";
        String credentialsFilePath = "path/to/your/credentials-file.json";

        try {
            // Set up Google Cloud credentials
            GoogleCredentials credentials = GoogleCredentials.fromStream(new FileInputStream(credentialsFilePath))
                    .createScoped(AutoMlTranslationSettings.getDefaultApiClient().getScopes());

            // Set up AutoML Translation client
            try (AutoMlTranslationClient translationClient = AutoMlTranslationClient.create(
                    AutoMlTranslationSettings.newBuilder()
                            .setCredentialsProvider(() -> credentials)
                            .build())) {

                // Example text to translate
                String textToTranslate = "Translate this custom text.";

                // Translate text using the custom model
                String translatedText = translateText(translationClient, projectId, modelId, textToTranslate);

                // Display the translation result
                System.out.println("Original Text: " + textToTranslate);
                System.out.println("Translated Text: " + translatedText);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String translateText(
            AutoMlTranslationClient translationClient,
            String projectId,
            String modelId,
            String textToTranslate) {
        // Build the translation request
        TranslateTextRequest request =
                TranslateTextRequest.newBuilder()
                        .setContents(textToTranslate)
                        .setTargetLanguageCode("en")  // Set your target language code
                        .setModel("projects/" + projectId + "/locations/us-central1/models/" + modelId)
                        .build();

        // Perform the translation
        TranslateTextResponse response = translationClient.translateText(request);

        // Extract and return the translated text
        Value translatedValue = response.getTranslations(0).getTranslatedText();
        return translatedValue.getStringValue();
    }
}
