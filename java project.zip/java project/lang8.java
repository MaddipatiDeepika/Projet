import com.google.cloud.translate.Translate;
import com.google.cloud.translate.TranslateOptions;
import com.google.cloud.translate.Detection;
import com.google.cloud.translate.Translation;

public class LanguageDetectionExample {

    public static void main(String[] args) {
        // Replace with your Google Cloud Translation API key
        String apiKey = "YOUR_API_KEY";

        // Input text for language detection and translation
        String inputText = "Hola, ¿cómo estás?";

        try {
            // Detect the language of the input text
            String detectedLanguage = detectLanguage(apiKey, inputText);

            // Translate the text to English (or any desired target language)
            String translatedText = translateText(apiKey, inputText, detectedLanguage, "en");

            // Display the results
            System.out.println("Input Text: " + inputText);
            System.out.println("Detected Language: " + detectedLanguage);
            System.out.println("Translated Text: " + translatedText);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String detectLanguage(String apiKey, String text) {
        // Set up Google Cloud Translation API
        Translate translate = TranslateOptions.newBuilder().setApiKey(apiKey).build().getService();

        // Detect the language of the input text
        Detection detection = translate.detect(text);
        return detection.getLanguage();
    }

    private static String translateText(String apiKey, String text, String sourceLanguage, String targetLanguage) {
        // Set up Google Cloud Translation API
        Translate translate = TranslateOptions.newBuilder().setApiKey(apiKey).build().getService();

        // Translate the text to the target language
        Translation translation = translate.translate(text,
                Translate.TranslateOption.sourceLanguage(sourceLanguage),
                Translate.TranslateOption.targetLanguage(targetLanguage));

        return translation.getTranslatedText();
    }
}
