import com.azure.ai.textanalytics.TextAnalyticsClientBuilder;
import com.azure.ai.textanalytics.models.DetectLanguageInput;
import com.azure.ai.textanalytics.models.DetectLanguageResult;
import com.azure.ai.textanalytics.models.DetectedLanguage;
import com.azure.ai.textanalytics.models.TranslateOptions;
import com.azure.ai.textanalytics.models.TranslateResult;
import com.azure.ai.textanalytics.TextAnalyticsClient;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.ai.textanalytics.models.TextDocumentInput;
import com.azure.ai.textanalytics.models.TextTranslationBatchResult;
import com.azure.ai.textanalytics.TextAnalyticsServiceVersion;

import com.microsoft.cognitiveservices.speech.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class SpeechTranslationExample {

    // Replace these with your actual Azure subscription key, endpoint, and region
    private static final String subscriptionKey = "YOUR_SUBSCRIPTION_KEY";
    private static final String serviceRegion = "YOUR_SERVICE_REGION";
    private static final String endpoint = "YOUR_ENDPOINT";

    public static void main(String[] args) {
        // Set up Azure Speech configuration
        SpeechConfig speechConfig = SpeechConfig.fromSubscription(subscriptionKey, serviceRegion);
        speechConfig.setEndpoint(endpoint);

        // Set up Azure Text Analytics configuration
        AzureKeyCredential credentials = new AzureKeyCredential(subscriptionKey);
        TextAnalyticsClient textAnalyticsClient = new TextAnalyticsClientBuilder()
                .credential(credentials)
                .endpoint(endpoint)
                .serviceVersion(TextAnalyticsServiceVersion.V3_1)
                .buildClient();

        // Example spoken text
        String spokenText = "Hello, how are you?";
        System.out.println("Spoken Text: " + spokenText);

        // Perform speech-to-text
        String recognizedText = performSpeechToText(speechConfig, spokenText);
        System.out.println("Recognized Text: " + recognizedText);

        // Perform language detection
        DetectedLanguage detectedLanguage = detectLanguage(textAnalyticsClient, recognizedText);

        // Perform text translation
        String targetLanguage = "es"; // Spanish (you can change it to your desired target language code)
        String translatedText = performTextTranslation(textAnalyticsClient, recognizedText, detectedLanguage, targetLanguage);
        System.out.println("Translated Text (" + targetLanguage + "): " + translatedText);

        // Perform text-to-speech
        performTextToSpeech(speechConfig, translatedText);
    }

    private static String performSpeechToText(SpeechConfig speechConfig, String spokenText) {
        try (SpeechRecognizer recognizer = new SpeechRecognizer(speechConfig)) {
            SpeechRecognitionResult result = recognizer.recognizeOnceAsync().get();
            return result.getText();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private static DetectedLanguage detectLanguage(TextAnalyticsClient textAnalyticsClient, String text) {
        DetectLanguageInput detectLanguageInput = new DetectLanguageInput(text);
        DetectLanguageResult detectLanguageResult = textAnalyticsClient.detectLanguage(detectLanguageInput);
        return detectLanguageResult.getPrimaryLanguage();
    }

    private static String performTextTranslation(
            TextAnalyticsClient textAnalyticsClient,
            String text,
            DetectedLanguage sourceLanguage,
            String targetLanguage) {

        TextDocumentInput document = new TextDocumentInput("1", text).setLanguage(sourceLanguage.getIso6391Name());
        TextTranslationBatchResult translationBatchResult = textAnalyticsClient.translateTextBatch(document, targetLanguage);
        return translationBatchResult.getDocuments().get(0).getTranslatedText();
    }

    private static void performTextToSpeech(SpeechConfig speechConfig, String textToSpeak) {
        try (SpeechSynthesizer synthesizer = new SpeechSynthesizer(speechConfig)) {
            // Set the voice to use for synthesis (you can change it to your desired voice)
            VoiceSelectionParams voice = new VoiceSelectionParams().setVoiceName("en-US-AriaNeural");
            SpeechSynthesisResult synthesisResult = synthesizer.SpeakSsmlAsync(textToSpeak, voice, null).get();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
