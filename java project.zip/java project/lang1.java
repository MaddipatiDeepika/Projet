import com.google.cloud.translate.Translate;
import com.google.cloud.translate.TranslateOptions;
import com.google.cloud.translate.Translation;

public class TextTranslator {

    public static void main(String[] args) {
        // Replace YOUR_API_KEY with your actual Google Cloud API key
        String apiKey = "YOUR_API_KEY";

        // Create a Translate object using the API key
        Translate translate = TranslateOptions.newBuilder().setApiKey(apiKey).build().getService();

        // Text to be translated
        String inputText = "Hello, world!";

        // Target languages (you can add more languages as needed)
        String[] targetLanguages = {"es", "fr", "de"};

        // Translate the text into multiple languages
        for (String targetLanguage : targetLanguages) {
            Translation translation = translate.translate(inputText, Translate.TranslateOption.targetLanguage(targetLanguage));

            // Display the translation results
            System.out.println("Original Text: " + inputText);
            System.out.println("Translated Text (" + targetLanguage + "): " + translation.getTranslatedText());
            System.out.println();
        }
    }
}
